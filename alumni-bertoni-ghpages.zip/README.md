# Alumni Pensionato Bertoni (static site)

Struttura:
- `index.html`
- `assets/foto/francesco_sala.jpg`

## Deploy su GitHub Pages
1. Crea un repository (pubblico) su GitHub, es. `alumni-bertoni`.
2. Carica i file di questa cartella (index.html + assets/**).
3. Vai su **Settings → Pages** e in **Build and deployment** imposta:
   - Source: **Deploy from a branch**
   - Branch: **main** / root (`/`)
4. L'URL sarà `https://<tuo-username>.github.io/alumni-bertoni/`.

Nota: il form aggiunge profili solo in memoria. Per salvataggio permanente collega un backend (Google Apps Script / Airtable / Supabase).
